import streamlit as st
from streamlit_option_menu import option_menu
from pages import home, disease_detector, blog, graphs, readme

# Page configuration for wide layout
st.set_page_config(
    page_title="LeafGuard", 
    layout="wide"  # No need to specify sidebar state
)

# Hide the sidebar completely with CSS
hide_sidebar_style = """
    <style>
        [data-testid="stSidebar"] {
            display: none;
        }
    </style>
"""
st.markdown(hide_sidebar_style, unsafe_allow_html=True)

# Topbar Navigation
selected = option_menu(
    menu_title=None,  # No need for a title
    options=["Home", "Disease Detector", "Blog", "Graphs", "Readme"],
    icons=["house", "search", "book", "bar-chart", "info-circle"],
    menu_icon="cast", 
    default_index=0,
    orientation="horizontal",  # This ensures the menu is horizontal
    styles={
        "container": {
            "padding": "10px!important",
            "background": "linear-gradient(135deg, #fafafa 30%, #e0e0e0 100%)",
            "border-bottom": "2px solid #e0e0e0",
            "box-shadow": "0 2px 5px rgba(0, 0, 0, 0.1)"
        },
        "icon": {
            "color": "#4CAF50",  # Change the icon color
            "font-size": "20px",
            "padding": "5px",
            "transition": "transform 0.3s ease",
        },
        "nav-link": {
            "font-size": "16px",
            "text-align": "center",
            "margin": "0px 15px",  # Increased horizontal spacing
            "padding": "10px 15px",  # Added padding for better touch targets
            "border-radius": "5px",
            "color": "#333",  # Default text color
            "--hover-color": "#e8f5e9",  # Light green on hover
            "transition": "background-color 0.3s ease, transform 0.3s ease",
        },
        "nav-link-selected": {
            "background-color": "#388E3C",  # Darker green for selected
            "color": "white",  # Text color for selected
            "border-radius": "5px",
            "border-bottom": "2px solid #ffffff",  # White underline for active link
        },
        # Media queries for responsiveness
        "@media (max-width: 768px)": {
            "nav-link": {
                "font-size": "14px",
                "margin": "0px 10px",
                "padding": "8px 10px",
            },
        },
    }
)

# Routing to different pages based on selection
if selected == "Home":
    home.show()
elif selected == "Disease Detector":
    disease_detector.show()
elif selected == "Blog":
    blog.show()
elif selected == "Graphs":
    graphs.show()
elif selected == "Readme":
    readme.show()
