import streamlit as st
from streamlit_lottie import st_lottie
import json
import os

# Set page configuration
st.set_page_config(page_title="Home", layout="wide")

# Function to load Lottie animations from a local file
def load_lottie_file(filepath: str):
    abs_path = os.path.abspath(filepath)  # Get absolute path
    st.write(f"Trying to load file from: {abs_path}")  # Log the absolute path
    try:
        with open(abs_path, "r", encoding="utf-8") as f:
            lottie_json = json.load(f)
            st.write("Lottie JSON loaded successfully.")  # Confirmation
            return lottie_json
    except FileNotFoundError:
        st.error("Lottie file not found. Please ensure the file exists.")
        return None
    except json.JSONDecodeError as e:
        st.error(f"Error decoding the Lottie JSON file: {e}")
        return None

# Display current working directory and list files in the assets folder
st.write("Current working directory:", os.getcwd())
if os.path.exists("assets"):
    assets_files = os.listdir("assets")
    st.write("Files in assets folder:", assets_files)
    if "scan.json" not in assets_files:
        st.error("'scan.json' not found in assets folder.")
else:
    st.error("'assets' folder not found. Please ensure the folder exists and contains the scan.json file.")

# Load Lottie animation from local assets (scan.json)
lottie_leaf_scan = load_lottie_file("assets/scan.json")

# Optional: Display the raw JSON for debugging
if lottie_leaf_scan:
    st.write("Lottie JSON content:", lottie_leaf_scan)

# Streamlit layout
def show():
    st.title("Welcome to the LeafGuard")

    # Create two columns: left for title/paragraph and right for Lottie animation
    col1, col2 = st.columns([2, 1])  # Left column takes more space

    with col1:
        st.header("Leaf Scan Detection System")
        st.write("""
        Captured through drones, smartphones, or cameras mounted on tractors, images provide valuable information about leaf health.
        High-resolution images can reveal subtle symptoms of diseases that might be missed by the naked eye.

        Data Science involves extracting knowledge and insights from structured and unstructured data using various techniques,
        including statistical analysis, machine learning, and data visualization. In the context of LeafGuard, Data Science techniques
        are employed to build predictive models that can identify and classify leaf diseases based on the data collected.

        Machine learning algorithms can analyze complex datasets and identify patterns that may not be immediately apparent to human observers.
        For instance, convolutional neural networks (CNNs) can be employed for image recognition tasks, enabling the system to learn from
        thousands of images of healthy and diseased leaves. This capability enhances the model's accuracy and reliability in real-world applications.
    """)

    with col2:
        if lottie_leaf_scan:
            st_lottie(lottie_leaf_scan, height=300, key="leaf_scan")  # Display the animation if it was loaded
        else:
            st.error("Failed to load the leaf scan animation.")  # Display error if loading failed

# Display the page
show()
