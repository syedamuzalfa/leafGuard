import streamlit as st

def show():
    st.title("Readme")
    st.write("This page describes the documentation and usage of the app.")
