import streamlit as st

# Function to add custom CSS with Inter font from Google Fonts
def add_custom_css():
    st.markdown("""
    <!-- Import Inter font from Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* Apply Inter font to the entire app */
        body, .stApp {
            font-family: 'Inter', sans-serif;
            background-color: #121212; /* Optional: Set a dark background for better contrast */
        }

        /* Style the title */
        .stApp h1 {
            color: white;
            font-weight: 700; /* Bold */
        }

        /* Style blog headers */
        .stApp h2 {
            color: #CCCCCC;
            font-weight: 600; /* Semi-bold */
        }

        /* Style the text content */
        .stApp p {
            color: white;
            line-height: 1.6;
            font-weight: 400; /* Regular */
        }

        /* Customize the "Read More" button */
        .stButton button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 10px 2px;
            cursor: pointer;
            border-radius: 4px;
            font-family: 'Inter', sans-serif; /* Ensure button text uses Inter */
        }

        /* Button hover effect */
        .stButton button:hover {
            background-color: #45a049;
        }

        /* Optional: Style links to match the theme */
        .stApp a {
            color: #4CAF50;
            text-decoration: none;
            font-weight: 600;
        }

        .stApp a:hover {
            text-decoration: underline;
        }
    </style>
    """, unsafe_allow_html=True)

def show():
    # Add the custom CSS
    add_custom_css()

    st.title("Transforming Big Data with Data Science")

    st.write("""
        In the realm of agriculture, leaf diseases pose a critical threat to crop yields and overall agricultural productivity. These diseases can lead to devastating yield losses, affecting the quality of produce and posing significant risks to food security and economic stability for farmers worldwide. The Food and Agriculture Organization (FAO) estimates that plant diseases can cause losses of up to 30% of potential crop yields, emphasizing the urgent need for effective detection and management strategies.

        Traditionally, detecting leaf diseases has relied heavily on manual inspection by experts. This method, while valuable, is labor-intensive, time-consuming, and often impractical for large-scale farming operations. The complexity and diversity of diseases can make visual identification challenging, leading to delayed responses and further crop losses.

        However, the advent of technology and data-driven methodologies has ushered in new possibilities. By leveraging Data Science and Big Data processing, we can revolutionize how leaf diseases are detected and managed. The LeafGuard project epitomizes this transformation, aiming to create a robust and interactive model that utilizes vast amounts of data—from images and weather patterns to soil conditions—to enhance disease detection and intervention strategies.
    """)

    # "Read More" button redirecting to an external site
    if st.button("Read More"):
        st.write("Redirecting to full blog post...")
        st.markdown("[Click here to read the full post](https://techwiz-leafguard.blogspot.com/2024/09/transforming-big-data-with-data-science.html)", unsafe_allow_html=True)

    # Placeholder for adding future blog posts
    st.write("**More blog posts coming soon!**")

# Call the show function
if __name__ == "__main__":
    show()
    