import streamlit as st
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LogisticRegression

# Function to create a plot
def create_plot(x, y, title):
    fig, ax = plt.subplots()
    ax.plot(x, y)
    ax.set_title(title)
    ax.set_xlabel('X-axis')
    ax.set_ylabel('Y-axis')
    return fig

# Function to simulate plant disease prediction
def predict_disease(features):
    # Dummy model for demonstration
    model = LogisticRegression()
    # Dummy data for training (features and labels)
    X_train = np.array([[0, 0], [1, 1], [1, 0], [0, 1]])
    y_train = np.array([0, 1, 1, 0])  # Binary classification (healthy/diseased)
    
    model.fit(X_train, y_train)
    return model.predict([features])[0]

# Main function to display the app
def show():
    st.title("Plant Disease Prediction and Graphs")

    # Create columns for cards
    col1, col2 = st.columns(2)

    # Card 1: Sine Wave
    with col1:
        st.markdown("### Sine Wave")
        x = np.linspace(0, 10, 100)
        y = np.sin(x)
        fig1 = create_plot(x, y, "Sine Function")
        st.pyplot(fig1)

    # Card 2: Cosine Wave
    with col2:
        st.markdown("### Cosine Wave")
        y = np.cos(x)
        fig2 = create_plot(x, y, "Cosine Function")
        st.pyplot(fig2)

    # Card 3: Tangent Wave
    with col1:
        st.markdown("### Tangent Wave")
        y = np.tan(x)
        fig3 = create_plot(x, y, "Tangent Function")
        st.pyplot(fig3)

    # Card 4: Exponential Function
    with col2:
        st.markdown("### Exponential Function")
        y = np.exp(x)
        fig4 = create_plot(x, y, "Exponential Function")
        st.pyplot(fig4)

    # Prediction Section
    st.subheader("Plant Disease Prediction")
    
    # Input features for prediction (for example: moisture and temperature)
    moisture = st.number_input("Moisture Level", min_value=0.0, max_value=100.0)
    temperature = st.number_input("Temperature Level", min_value=0.0, max_value=100.0)

    if st.button("Predict Disease"):
        features = [moisture / 100.0, temperature / 100.0]  # Normalize input
        prediction = predict_disease(features)
        disease_status = "Diseased" if prediction == 1 else "Healthy"
        st.success(f"The plant is predicted to be: **{disease_status}**")

# Run the app
if __name__ == "__main__":
    show()